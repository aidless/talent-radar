# 天赋雷达 · 成品包说明（卖家用 / 买家通用）

> 本文档是打包与上架手册：包内有什么、怎么交付、上架前要替换哪些占位。

## 包内清单

| 文件 | 说明 |
|---|---|
| `index.html` | 天赋雷达主工具（40 题自测 + 10 维雷达 + 分享卡片 + 求职定位 + 本地 AI 深挖），单文件，双击即用 |
| `sell/index.html` | 销售页（含前 5 题试玩 iframe 与示例报告节选） |
| `serve.py` | 本地 AI 深挖服务：`python3 serve.py` 后从 http://127.0.0.1:8018 打开工具，页面内即可 AI 追问（走自有 Magpie 网关反代）；匿名数据池需额外设置环境变量 `TALENT_RADAR_RESEARCH_KEY` 才会启用，未设置时上传返回 503（功能未启用，不影响其他功能） |
| `prompts.md` | Prompt 三件套完整文本（可单独交付或导入 GPTs / Claude Skill） |
| `README.md` | 本文档 |

## Prompt 三件套导入方式

1. **GPTs**：ChatGPT → Create a GPT → Instructions 粘贴 `prompts.md` 的 Prompt A + B + C 全文 → 名字建议「天赋挖掘师」。
2. **Claude Skill**：建目录 `talent-digger/`，`SKILL.md` 的 frontmatter name=`talent-digger`、description 写「用户想挖掘自身天赋时使用，一次一题追问式」，正文放三段 Prompt。
3. **裸用**：直接复制进任意 AI 对话框。

## 上架前必须替换的占位

- `sell/index.html` 中 `[购买链接]` 是**占位待替换**：发布前改成你的实际收款/发货链接（面包多 / 爱发电 / 小报童 / Gumroad）。未替换前不可公开部署。
- `talent-radar/launch.md` 含发布文案与 FAQ；上架前一并核对口径。
- `sell/index.html` 价格 `¥39` 与划线价按你的定价改。
- 演示 iframe 引用 `../index.html?demo=1`（前 5 题试玩）：如果销售页单独部署，把工具文件放到同级目录或改成完整 URL。

## 交付方式建议

- **轻交付**：只发 `index.html` + `prompts.md`（买家双击即用）。
- **完整交付**：整个 zip（含 serve.py 与销售页）。
- 发布渠道：面包多 / 爱发电 / 小报童 / Gumroad / 独立站。商品图直接用工具的「生成分享卡片」输出。

## 本地验证（卖家上架前自检）

```bash
# 1. 主工具语法（node 环境）
python3 -c "import re,pathlib;pathlib.Path('/tmp/t.js').write_text(re.search(r'<script>(.*?)</script>',pathlib.Path('index.html').read_text(),re.S).group(1))"
node --check /tmp/t.js

# 2. 本地 AI 深挖
python3 serve.py &          # 启动后浏览器开 http://127.0.0.1:8018
curl -s http://127.0.0.1:8018/v1/models | head -c 200

# 3. 销售页演示 iframe
python3 -m http.server 8019 # 开 http://127.0.0.1:8019/sell/ 确认演示可玩
```
